USE SQL_CLASS_5;

-- Views
drop table Employees; 
CREATE TABLE Employees (
    EmployeeID INT PRIMARY KEY,
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    Department VARCHAR(50),
    Salary DECIMAL(10, 2)
);
INSERT INTO Employees (EmployeeID, FirstName, LastName, Department, Salary)
VALUES
    (1, 'John', 'Doe', 'HR', 50000.00),
    (2, 'Jane', 'Smith', 'IT', 60000.00),
    (3, 'Bob', 'Johnson', 'Finance', 55000.00),
    (4, 'Alice', 'Williams', 'Marketing', 52000.00),
    (5, 'Eve', 'Anderson', 'IT', 62000.00);

Select * from Employees; 

-- CREATE A VIEW

CREATE VIEW EmployeeNames AS
SELECT EmployeeID, FirstName, LastName
FROM Employees;

SELECT * FROM EmployeeNames;


-- CREATE OR REPLACE A VIEW

CREATE OR REPLACE VIEW EmployeeNames AS
SELECT EmployeeID, FirstName, LastName, Department
FROM Employees;

SELECT * FROM EmployeeNames;

-- DROP A VIEW

DROP VIEW EmployeeNames;


-- Stored procedures

/*
Suppose you have a database with a table named Employees
You want to create a stored procedure that retrieves all employees from a specific department.
Here's how you can create the stored procedure:*/

DROP PROCEDURE IF EXISTS GetEmployeesByDepartment;

DELIMITER //

CREATE PROCEDURE GetEmployeesByDepartment(IN DepartmentName VARCHAR(50))
BEGIN
    SELECT EmployeeID, FirstName, LastName
    FROM Employees
    WHERE Department = DepartmentName;
END //

DELIMITER ;

CALL GetEmployeesByDepartment('HR');



-- Indexes

drop table customer_orders; 
-- Create the customer_orders table
CREATE TABLE customer_orders (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    order_date DATE,
    customer_id INT,
    order_total DECIMAL(10, 2)
);

-- Create an index on the customer_id column
CREATE INDEX idx_customer_id ON customer_orders(customer_id);

-- Insert sample data
INSERT INTO customer_orders (order_date, customer_id, order_total)
VALUES
    ('2023-09-01', 101, 150.50),
    ('2023-09-02', 102, 200.25),
    ('2023-09-03', 101, 75.80),
    ('2023-09-04', 103, 120.60),
    ('2023-09-05', 102, 180.90);

SHOW INDEX FROM customer_orders;

SELECT * FROM customer_orders WHERE customer_id = 102;
-- Without an index, the database would need to perform a full table scan, examining each row in the customer_orders table to find all orders with customer_id equal to 102. This operation can be slow, especially if there are millions of rows in the table.


/*With the index on the customer_id column, the database can use the index to quickly locate all rows with customer_id equal to 102. It doesn't need to scan the entire table, resulting in much faster query performance.

In a real-world scenario, as the size of the customer_orders table grows, the difference in query performance becomes even more pronounced. The index allows the database to perform the query efficiently, making it ideal for scenarios where you frequently need to retrieve data based on the indexed column's values, such as retrieving all orders for a specific customer in an e-commerce platform, as mentioned in the previous example.

Indexes are a fundamental optimization technique in database design, significantly improving query performance for commonly accessed data.
*/

DROP INDEX idx_customer_id ON customer_orders;