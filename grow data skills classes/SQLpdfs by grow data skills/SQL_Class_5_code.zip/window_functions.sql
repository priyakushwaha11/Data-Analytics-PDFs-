create database sql_class_5;

use sql_class_5;

drop table employee;
create table employee
( emp_ID int
, emp_NAME varchar(50)
, DEPT_NAME varchar(50)
, SALARY int);

insert into employee values(101, 'Mohan', 'Admin', 4000);
insert into employee values(102, 'Rajkumar', 'HR', 3000);
insert into employee values(103, 'Akbar', 'IT', 4000);
insert into employee values(104, 'Dorvin', 'Finance', 6500);
insert into employee values(105, 'Rohit', 'HR', 3000);
insert into employee values(106, 'Rajesh',  'Finance', 5000);
insert into employee values(107, 'Preet', 'HR', 7000);
insert into employee values(108, 'Maryam', 'Admin', 4000);
insert into employee values(109, 'Sanjay', 'IT', 6500);
insert into employee values(110, 'Vasudha', 'IT', 7000);
insert into employee values(111, 'Melinda', 'IT', 8000);
insert into employee values(112, 'Komal', 'IT', 10000);
insert into employee values(113, 'Gautham', 'Admin', 2000);
insert into employee values(114, 'Manisha', 'HR', 3000);
insert into employee values(115, 'Chandni', 'IT', 4500);
insert into employee values(116, 'Satya', 'Finance', 6500);
insert into employee values(117, 'Adarsh', 'HR', 3500);
insert into employee values(118, 'Tejaswi', 'Finance', 5500);
insert into employee values(119, 'Cory', 'HR', 8000);
insert into employee values(120, 'Monica', 'Admin', 5000);
insert into employee values(121, 'Rosalin', 'IT', 6000);
insert into employee values(122, 'Ibrahim', 'IT', 8000);
insert into employee values(123, 'Vikram', 'IT', 8000);
insert into employee values(124, 'Dheeraj', 'IT', 11000);
COMMIT;


select * from employee;

select max(salary) from employee;


-- Using Aggregate function as Window Function
-- Without window function, SQL will reduce the no of records.
select dept_name, max(salary) from employee
group by dept_name;

-- By using MAX as an window function, SQL will not reduce records but the result will be shown corresponding to each record.
select e.*,
max(salary) over() as max_salary
from employee e;

select e.*,
max(salary) over(partition by dept_name) as max_salary
from employee e;
-- Similarly we can use other aggregate function like min, sum etc as window functions.


-- row_number(), rank() and dense_rank()

select *,
row_number() over() as rn
from employee;

select *,
row_number() over(partition by dept_name) as rn
from employee;

select *,
row_number() over(partition by dept_name order by emp_id) as rn
from employee;


-- Fetch the first 2 employees from each department to join the company.
select * from (
	select *,
	row_number() over(partition by dept_name order by emp_id) as rn
	from employee) x
where x.rn < 3;

-- RANK
select *,
rank() over(partition by dept_name order by salary desc) as rnk
from employee;

-- Fetch the top 3 employees in each department earning the max salary.
select * from (
	select *,
	rank() over(partition by dept_name order by salary desc) as rnk
	from employee) x
where x.rnk < 4;

-- DENSE_RANK

select *,
rank() over(partition by dept_name order by salary desc) as rnk,
dense_rank() over(partition by dept_name order by salary desc) as dense_rnk
from employee;


-- Checking the different between rank, dense_rnk and row_number window functions:
select *,
rank() over(partition by dept_name order by salary desc) as rnk,
dense_rank() over(partition by dept_name order by salary desc) as dense_rnk,
row_number() over(partition by dept_name order by salary desc) as rn
from employee;


-- lead and lag
select *,
lag(salary) over(partition by dept_name order by emp_id) as prev_empl_sal
from employee;

select *,
lag(salary,2,0) over(partition by dept_name order by emp_id) as prev_empl_sal
from employee;

-- Similarly using lead function to see how it is different from lag.
select *,
lag(salary) over(partition by dept_name order by emp_id) as prev_empl_sal,
lead(salary) over(partition by dept_name order by emp_id) as next_empl_sal
from employee;


-- fetch a query to display if the salary of an employee is higher, lower or equal to the previous employee.
select *,
lag(salary) over(partition by dept_name order by emp_id) as prev_empl_sal,
case when salary > lag(salary) over(partition by dept_name order by emp_id) then 'Higher than previous employee'
     when salary < lag(salary) over(partition by dept_name order by emp_id) then 'Lower than previous employee'
	 when salary = lag(salary) over(partition by dept_name order by emp_id) then 'Same than previous employee' end as sal_range
from employee;


-- Script to create the Product table and load data into it.

DROP TABLE product;
CREATE TABLE product
( 
    product_category varchar(255),
    brand varchar(255),
    product_name varchar(255),
    price int
);

INSERT INTO product VALUES
('Phone', 'Apple', 'iPhone 12 Pro Max', 1300),
('Phone', 'Apple', 'iPhone 12 Pro', 1100),
('Phone', 'Apple', 'iPhone 12', 1000),
('Phone', 'Samsung', 'Galaxy Z Fold 3', 1800),
('Phone', 'Samsung', 'Galaxy Z Flip 3', 1000),
('Phone', 'Samsung', 'Galaxy Note 20', 1200),
('Phone', 'Samsung', 'Galaxy S21', 1000),
('Phone', 'OnePlus', 'OnePlus Nord', 300),
('Phone', 'OnePlus', 'OnePlus 9', 800),
('Phone', 'Google', 'Pixel 5', 600),
('Laptop', 'Apple', 'MacBook Pro 13', 2000),
('Laptop', 'Apple', 'MacBook Air', 1200),
('Laptop', 'Microsoft', 'Surface Laptop 4', 2100),
('Laptop', 'Dell', 'XPS 13', 2000),
('Laptop', 'Dell', 'XPS 15', 2300),
('Laptop', 'Dell', 'XPS 17', 2500),
('Earphone', 'Apple', 'AirPods Pro', 280),
('Earphone', 'Samsung', 'Galaxy Buds Pro', 220),
('Earphone', 'Samsung', 'Galaxy Buds Live', 170),
('Earphone', 'Sony', 'WF-1000XM4', 250),
('Headphone', 'Sony', 'WH-1000XM4', 400),
('Headphone', 'Apple', 'AirPods Max', 550),
('Headphone', 'Microsoft', 'Surface Headphones 2', 250),
('Smartwatch', 'Apple', 'Apple Watch Series 6', 1000),
('Smartwatch', 'Apple', 'Apple Watch SE', 400),
('Smartwatch', 'Samsung', 'Galaxy Watch 4', 600),
('Smartwatch', 'OnePlus', 'OnePlus Watch', 220);
COMMIT;

select * from product;


-- FIRST_VALUE 
-- Write query to display the most expensive product under each category (corresponding to each record)
select *,
first_value(product_name) over() as most_exp_product
from product;

select *,
first_value(product_name) over(partition by product_category order by price desc) as most_exp_product
from product;


-- LAST_VALUE 
-- Write query to display the least expensive product under each category (corresponding to each record)
select *,
last_value(product_name) over(partition by product_category order by price desc) as least_exp_product
from product;

-- Frame clause(default)

select *,
first_value(product_name) over(partition by product_category order by price desc) as most_exp_product,
last_value(product_name) over(partition by product_category order by price desc
                              range between unbounded preceding and current row) as least_exp_product    
from product;

-- Changing frame clause for correct values
select *,
first_value(product_name) over(partition by product_category order by price desc) as most_exp_product,
last_value(product_name) over(partition by product_category order by price desc
                              range between unbounded preceding and unbounded following) as least_exp_product    
from product;

-- rows (similar to range, difference only when duplicates)

select *,
first_value(product_name) over(partition by product_category order by price desc) as most_exp_product,
last_value(product_name) over(partition by product_category order by price desc
                              rows between unbounded preceding and unbounded following) as least_exp_product    
from product;

-- duplicate data example
select *,
last_value(product_name) over(partition by product_category order by price desc
                             range between unbounded preceding and current row) as least_exp_product    
from product
WHERE product_category ='Phone'; 

select *,
last_value(product_name) over(partition by product_category order by price desc
                              rows between unbounded preceding and current row) as least_exp_product    
from product
WHERE product_category ='Phone';

-- Other frame clause
select *,
first_value(product_name) over(partition by product_category order by price desc
                             range between 2 preceding and 2 following) as most_exp_product ,
last_value(product_name) over(partition by product_category order by price desc
                              rows between 2 preceding and 2 following) as least_exp_product    
from product
WHERE product_category ='Phone';



-- Alternate way to write SQL query using Window functions
select *,
first_value(product_name) over w as most_exp_product,
last_value(product_name) over w as least_exp_product    
from product
WHERE product_category ='Phone'
window w as (partition by product_category order by price desc
            range between unbounded preceding and unbounded following);
            

            
-- NTH_VALUE 
-- Write query to display the Second most expensive product under each category.
select *,
nth_value(product_name, 2) over w as second_most_exp_product
from product
window w as (partition by product_category order by price desc
            range between unbounded preceding and unbounded following);
